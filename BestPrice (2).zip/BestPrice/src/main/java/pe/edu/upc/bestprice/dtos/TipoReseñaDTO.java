package pe.edu.upc.bestprice.dtos;

public class TipoReseñaDTO {
}
