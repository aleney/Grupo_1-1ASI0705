package pe.edu.upc.bestprice.dtos;

public class HistorialBusquedaDTO {
}
