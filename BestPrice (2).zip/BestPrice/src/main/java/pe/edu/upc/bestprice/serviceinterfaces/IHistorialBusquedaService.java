package pe.edu.upc.bestprice.serviceinterfaces;

public interface IHistorialBusquedaService {
}
