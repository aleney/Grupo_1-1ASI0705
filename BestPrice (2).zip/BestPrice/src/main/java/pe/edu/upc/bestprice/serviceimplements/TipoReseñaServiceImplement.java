package pe.edu.upc.bestprice.serviceimplements;

public class TipoReseñaServiceImplement {
}
