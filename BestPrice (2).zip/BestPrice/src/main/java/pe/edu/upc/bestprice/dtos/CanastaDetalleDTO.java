package pe.edu.upc.bestprice.dtos;

public class CanastaDetalleDTO {
    private String idCanastaDetalle;
    private int cantidadCanastaDetalle;
    private int productoCanastaDetalle;
    private int canastaCanastaDetalle;

    public String getIdCanastaDetalle() {
        return idCanastaDetalle;
    }

    public void setIdCanastaDetalle(String idCanastaDetalle) {
        this.idCanastaDetalle = idCanastaDetalle;
    }

    public int getCantidadCanastaDetalle() {
        return cantidadCanastaDetalle;
    }

    public void setCantidadCanastaDetalle(int cantidadCanastaDetalle) {
        this.cantidadCanastaDetalle = cantidadCanastaDetalle;
    }

    public int getProductoCanastaDetalle() {
        return productoCanastaDetalle;
    }

    public void setProductoCanastaDetalle(int productoCanastaDetalle) {
        this.productoCanastaDetalle = productoCanastaDetalle;
    }

    public int getCanastaCanastaDetalle() {
        return canastaCanastaDetalle;
    }

    public void setCanastaCanastaDetalle(int canastaCanastaDetalle) {
        this.canastaCanastaDetalle = canastaCanastaDetalle;
    }
}
