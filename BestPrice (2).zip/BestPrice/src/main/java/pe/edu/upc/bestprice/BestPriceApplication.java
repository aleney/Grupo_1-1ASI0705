package pe.edu.upc.bestprice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestPriceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BestPriceApplication.class, args);
    }

}
