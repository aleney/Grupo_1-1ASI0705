package pe.edu.upc.bestprice.controllers;

public class HistorialBusquedaController {
}
