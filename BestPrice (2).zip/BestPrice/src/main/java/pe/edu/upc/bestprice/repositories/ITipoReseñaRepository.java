package pe.edu.upc.bestprice.repositories;

public interface ITipoReseñaRepository {
}
